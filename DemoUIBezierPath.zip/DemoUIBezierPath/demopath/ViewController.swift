//
//  ViewController.swift
//  demopath
//
//  Created by macpc on 21/03/16.
//  Copyright (c) 2016 macpc. All rights reserved.
//

import UIKit
import CoreLocation
import CoreMotion

class ViewController: UIViewController, CLLocationManagerDelegate, UIScrollViewDelegate {
    
    var xincrease = Bool()
    var yincrease = Bool()
    var xdecrease =  Bool()
    var ydecrease = Bool()
    
    var tempX = NSInteger()
    var tempContentsize = NSInteger()
    var lasttempcounter = NSInteger()
    
    
    
    var lastdirection = NSString()
    var FirstPosition = Bool()
    var isnull = Bool()
    var myview = UIView();
    
    var degreearray = NSMutableArray();
    var dictdegree = NSMutableDictionary()
    var NewSpacecounter = NSInteger();
    
    var StartX = NSInteger()
    var StartY = NSInteger()
   // var stepcounter = NSInteger();
    
    var locationManager:CLLocationManager!
    var latitudeOfTargetedPoint: CLLocationDegrees?
    var longitudeOfTargetedPoint: CLLocationDegrees?
    var targetLocation: CLLocation?
    
    @IBOutlet var lblcounter: UILabel!
    @IBOutlet var lbldirection: UILabel!
    @IBOutlet weak var stateImageView: UIImageView!
    let activityManager = CMMotionActivityManager()
    
    
    let pedoMeter = CMPedometer()
    
    @IBOutlet var pathscroll: UIScrollView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        isnull = true;
        StartX = 150;
        StartY = 400;
        NewSpacecounter = 5;
        FirstPosition = false
        
        degreearray = ["N","NE","E","SE","S","SW","W","NW"]
        self.locationManager = CLLocationManager()
        
        if CLLocationManager.locationServicesEnabled() {
            self.locationManager.delegate = self
            self.locationManager.desiredAccuracy = kCLLocationAccuracyBestForNavigation
            self.locationManager.distanceFilter = 10
        }
        self.view.backgroundColor = UIColor.whiteColor()
        locationManager.startUpdatingHeading()
        latitudeOfTargetedPoint = CLLocationDegrees(48.557257)
        longitudeOfTargetedPoint = CLLocationDegrees(2.968518)
        let cal = NSCalendar.currentCalendar()
        var comps = cal.components(NSCalendarUnit.YearCalendarUnit | .MonthCalendarUnit | .DayCalendarUnit | .HourCalendarUnit | .MinuteCalendarUnit | .SecondCalendarUnit, fromDate: NSDate())
        comps.hour = 0
        comps.minute = 0
        comps.second = 0
        let timeZone = NSTimeZone.systemTimeZone()
        cal.timeZone = timeZone
        let midnightOfToday = cal.dateFromComponents(comps)!
        
        
        
        if(CMPedometer.isStepCountingAvailable()){
            let fromDate = NSDate(timeIntervalSinceNow: 0)
            self.pedoMeter.queryPedometerDataFromDate(fromDate, toDate: NSDate()) { (data : CMPedometerData!, error) -> Void in
                println(data)
                dispatch_async(dispatch_get_main_queue(), { () -> Void in
                    if(error == nil){
                        // self.steps.text = "\(data.numberOfSteps)"
                    }
                })
                self.pedoMeter.startPedometerUpdatesFromDate(midnightOfToday) { (data: CMPedometerData!, error) -> Void in
                    dispatch_async(dispatch_get_main_queue(), { () -> Void in
                        if(error == nil){
                            
                            if(self.isnull == false)
                            {
                                if(self.FirstPosition == false)
                                {
                                    var derection:NSInteger = self.degreearray.indexOfObject(self.lbldirection.text!)
                                    var Directions = NSMutableArray()
                                    Directions = ["North","East","East1","East2","south","west","west1","west2"]
                                    var newindex = NSInteger()
                                    for var i = 0; i < self.degreearray.count; i++
                                    {
                                        var index = derection + i
                                        if(index > 7)
                                        {
                                            index = newindex;
                                            newindex++;
                                        }
                                        self.dictdegree.setValue(self.degreearray.objectAtIndex(index), forKey: Directions.objectAtIndex(i) as NSString)
                                    }
                                    self.FirstPosition = true;
                                }
                                var foundationDictionary:NSDictionary = NSDictionary(dictionary: self.dictdegree)
                                let keys:NSArray = foundationDictionary.allKeysForObject(self.lbldirection.text!) as NSArray
                                var directionString:String = keys.objectAtIndex(0) as String
                                
                                if self.lastdirection != directionString
                                {
                                    if directionString == "North"
                                    {
                                        self.xincrease = false
                                        self.yincrease = false
                                        self.xdecrease = false
                                        self.ydecrease = true
                                    }
                                    else if directionString == "south"
                                    {
                                        self.xincrease = false
                                        self.yincrease = true
                                        self.xdecrease = false
                                        self.ydecrease = false
                                    }
                                    else if directionString == "west" || directionString == "west1" || directionString == "west2"
                                    {
                                        if self.yincrease == true
                                        {
                                            self.StartY = self.StartY + 5
                                        }
                                        self.xincrease = false
                                        self.yincrease = false
                                        self.xdecrease = true
                                        self.ydecrease = false
                                    }
                                    else
                                    {
                                        if self.yincrease == true
                                        {
                                            self.StartY = self.StartY + 5
                                        }
                                        self.xincrease = true
                                        self.yincrease = false
                                        self.xdecrease = false
                                        self.ydecrease = false
                                    }
                                    self.lastdirection = directionString
                                }
                                self.sayHello(directionString)
                            }
                        }
                    })
                }
            }
        }
    }
    func sayHello(directionString: String) -> Void
    {
        var path: UIBezierPath = UIBezierPath()
        if directionString == "North"
        {
            StartY = StartY - 10
            path.moveToPoint(CGPoint(x: StartX, y: StartY))
            path.addLineToPoint(CGPoint(x: StartX, y: StartY + NewSpacecounter))
            
        }
        else if directionString == "south" {
            
            StartY = StartY + 10
            path.moveToPoint(CGPoint(x: StartX, y: StartY))
            path.addLineToPoint(CGPoint(x: StartX, y: StartY + NewSpacecounter))
            
        }
        else if directionString == "west" || directionString == "west1" || directionString == "west2"{
            
            StartX = StartX - 10
            path.moveToPoint(CGPoint(x: StartX, y: self.StartY))
            path.addLineToPoint(CGPoint(x: StartX + NewSpacecounter, y: self.StartY))
        }
        else
        {
            StartX = StartX + 10
            path.moveToPoint(CGPoint(x: StartX, y: self.StartY))
            path.addLineToPoint(CGPoint(x: StartX - NewSpacecounter, y: self.StartY))
        }
        var shapeLayer: CAShapeLayer = CAShapeLayer()
        shapeLayer.path = path.CGPath
        shapeLayer.strokeColor = UIColor.blueColor().CGColor
        shapeLayer.lineWidth = 3.0
        shapeLayer.fillColor = UIColor.clearColor().CGColor
        myview.layer.addSublayer(shapeLayer)
        self.pathscroll.addSubview(myview);
    }
    func locationManager(manager: CLLocationManager, didUpdateHeading newHeading: CLHeading) {
        
        var degrees: Float = Float(newHeading.magneticHeading)
        if degrees >= 337.5 || degrees < 22.5 {
            lbldirection.text = "N"
        }
        else if degrees >= 22.5 && degrees < 67.5 {
            lbldirection.text = "NE"
        }
        else if degrees >= 67.5 && degrees < 112.5 {
            lbldirection.text = "E"
        }
        else if degrees >= 112.5 && degrees < 157.5 {
            lbldirection.text = "SE"
        }
        else if degrees >= 157.5 && degrees < 202.5 {
            lbldirection.text = "S"
        }
        else if degrees >= 202.5 && degrees < 247.5 {
            lbldirection.text = "SW"
        }
        else if degrees >= 247.5 && degrees < 292.5 {
            lbldirection.text = "W"
        }
        else if degrees >= 292.5 && degrees < 337.5 {
            lbldirection.text = "NW"
        }
        isnull = false;
    }
    @IBAction func clearuiview(sender: UIButton) {
        StartX = 150
        StartY = 400
        self.isnull = false
        self.FirstPosition = false
        myview.layer.sublayers.removeAll(keepCapacity: true)
    }
    @IBAction func DrawPath(sender: UIButton) {
        
        if lasttempcounter != sender.tag
        {
            if sender.tag == 0
            {
                xincrease = false
                yincrease = false
                xdecrease = false
                ydecrease = true
            }
            else if sender.tag == 1
           {
            xincrease = false
            yincrease = true
            xdecrease = false
            ydecrease = false
            }
            else if sender.tag == 2
            {
                if yincrease == true
                {
                    self.StartY = self.StartY + 5
                }
                xincrease = false
                yincrease = false
                xdecrease = true
                ydecrease = false
            }
            else
            {
                if yincrease == true
                {
                    self.StartY = self.StartY + 5
                }
                xincrease = true
                yincrease = false
                xdecrease = false
                ydecrease = false
            }
            lasttempcounter = sender.tag
        }
        var path: UIBezierPath = UIBezierPath()
        if sender.tag == 0
        {
            StartY = StartY - 10
            path.moveToPoint(CGPoint(x: StartX, y: StartY))
            path.addLineToPoint(CGPoint(x: StartX, y: StartY + NewSpacecounter))
        }
        else if sender.tag == 1 {
            
            StartY = StartY + 10
            path.moveToPoint(CGPoint(x: StartX, y: StartY))
            path.addLineToPoint(CGPoint(x: StartX, y: StartY + NewSpacecounter))
        }
        else if sender.tag == 2{
            
            StartX = StartX - 10
            path.moveToPoint(CGPoint(x: StartX, y: self.StartY))
            path.addLineToPoint(CGPoint(x: StartX + NewSpacecounter, y: self.StartY))
        }
        else
        {
            StartX = StartX + 10
            path.moveToPoint(CGPoint(x: StartX, y: self.StartY))
            path.addLineToPoint(CGPoint(x: StartX - NewSpacecounter, y: self.StartY))
        }
        var shapeLayer: CAShapeLayer = CAShapeLayer()
        shapeLayer.path = path.CGPath
        shapeLayer.strokeColor = UIColor.blueColor().CGColor
        shapeLayer.lineWidth = 3.0
        shapeLayer.fillColor = UIColor.clearColor().CGColor
        if StartX < 0
        {
            tempX = StartX
            tempContentsize = 375 - StartX
            
        }
        else if(StartX > 320)
        {
            tempX = StartX - 350
            tempContentsize = 500 + StartX
        }
        else
        {
            tempContentsize = 375
            tempX = 0
        }
        
        myview.layer.addSublayer(shapeLayer)
        self.pathscroll.frame = CGRectMake(CGFloat(tempX), self.pathscroll.frame.origin.y, CGFloat(tempContentsize), self.pathscroll.frame.size.height)
        self.pathscroll.contentSize = CGSizeMake(CGFloat(tempContentsize), self.pathscroll.frame.size.height)
        self.pathscroll.setContentOffset(CGPointMake(CGFloat(tempX), 0), animated: true)
        self.pathscroll.addSubview(myview)
    }/*
    func scrollViewDidScroll(scrollView: UIScrollView) {
        self.pathscroll.contentSize = CGSizeMake(CGFloat(tempContentsize), 634)
        self.pathscroll.setContentOffset(CGPointMake(CGFloat(tempX), 102), animated: true)
    }*/
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}